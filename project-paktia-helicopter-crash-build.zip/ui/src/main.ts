import './style.css'

type CrashStep = { title: string; detail: string; phase: string; objective: string; tone: string }
const steps: CrashStep[] = [
  { title: 'FALCON-2 INBOUND', detail: 'AIR SUPPORT ENTERING PAKTIA VALLEY', phase: 'INBOUND', objective: 'MONITOR FALCON-2', tone: 'green' },
  { title: 'FALCON-2 DISTRESS', detail: 'FLIGHT CONTROL FAILURE // ENGINE CRITICAL', phase: 'DISTRESS', objective: 'TRACK LAST KNOWN POSITION', tone: 'amber' },
  { title: 'SIGNAL LOST', detail: 'TELEMETRY LINK TERMINATED', phase: 'SIGNAL LOST', objective: 'LAUNCH RAVEN SEARCH', tone: 'red' },
  { title: 'CRASH CONFIRMED', detail: 'IMPACT DETECTED // GRID R-17', phase: 'CRASH', objective: 'LOCATE AIRCRAFT', tone: 'red' },
  { title: 'RAVEN SEARCH ACTIVE', detail: 'OPTICAL SWEEP IN PROGRESS', phase: 'RECON', objective: 'CONFIRM CRASH SITE', tone: 'amber' },
  { title: 'CRASH SITE LOCATED', detail: 'SMOKE COLUMN AND EMERGENCY BEACON CONFIRMED', phase: 'LOCATED', objective: 'SECURE CRASH SITE', tone: 'green' },
  { title: 'CREW LOCATED', detail: 'PILOT INJURED // COPILOT CRITICAL // CREW CHIEF MOBILE', phase: 'RECOVERY', objective: 'ESTABLISH RECOVERY ZONE', tone: 'amber' },
  { title: 'RECOVERY UNDER ATTACK', detail: 'BRAVO HOLDING EASTERN APPROACH', phase: 'DEFENSE', objective: 'DEFEND RECOVERY ZONE', tone: 'red' },
  { title: 'FALCON CREW EVACUATED', detail: 'ALL THREE CREW MEMBERS RECOVERED', phase: 'COMPLETE', objective: 'RETURN TO CHECKPOINT ECHO', tone: 'green' }
]

let step = 0

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
<div class="world">
  <div class="topbar"><div><small>PROJECT PAKTIA // MISSION 01</small><h1>OPERATION MOUNTAIN SHIELD</h1></div><div class="phase">PHASE <b id="phase">COUNTERATTACK</b></div></div>
  <aside class="missionRail"><span>PRIMARY OBJECTIVE</span><strong id="objective">DEFEND CHECKPOINT ECHO</strong><div class="railLine"></div><button id="triggerCrash">TRIGGER FALCON EVENT</button><button id="nextStep" disabled>ADVANCE SEQUENCE</button></aside>
  <main class="battleMap">
    <div class="grid"></div><div class="route"></div><div class="radar"></div>
    <button class="mapMarker viper"><i></i>VIPER</button><button class="mapMarker echo"><i></i>ECHO</button><button class="mapMarker raven"><i></i>RAVEN-1</button>
    <button id="crashMarker" class="mapMarker crash hidden"><i></i>FALCON-2</button>
    <div id="smoke" class="smoke hidden"><span></span><span></span><span></span></div>
    <section id="alert" class="alert hidden"><div class="alertCode">PRIORITY EVENT</div><h2 id="alertTitle"></h2><p id="alertDetail"></p><div class="alertProgress"><i id="alertBar"></i></div></section>
    <section class="droneFeed"><header><b>RAVEN-1 // OPTICAL</b><span>LINK 91%</span></header><div class="feed"><div class="horizon"></div><div class="reticle"></div><div id="feedLabel">CHECKPOINT ECHO // TRACK ACTIVE</div></div></section>
  </main>
  <footer class="commandDock">
    <button><span>VIPER</span><b>READY</b></button><button><span>BRAVO</span><b>HOLDING</b></button><button><span>RAVEN</span><b class="ok">ACTIVE</b></button><button><span>WARDEN</span><b>ORBIT</b></button><button><span>TALON</span><b>AVAILABLE</b></button>
    <div class="crew"><span>FALCON CREW</span><b id="crewStatus">NOT DEPLOYED</b></div>
  </footer>
</div>`

const trigger = document.querySelector<HTMLButtonElement>('#triggerCrash')!
const next = document.querySelector<HTMLButtonElement>('#nextStep')!
const alert = document.querySelector<HTMLElement>('#alert')!
const crashMarker = document.querySelector<HTMLElement>('#crashMarker')!
const smoke = document.querySelector<HTMLElement>('#smoke')!

function render(): void {
  const current = steps[step]!
  alert.className = `alert ${current.tone}`
  document.querySelector('#alertTitle')!.textContent = current.title
  document.querySelector('#alertDetail')!.textContent = current.detail
  document.querySelector('#phase')!.textContent = current.phase
  document.querySelector('#objective')!.textContent = current.objective
  document.querySelector('#feedLabel')!.textContent = step >= 4 ? 'GRID R-17 // SEARCH MODE' : current.detail
  document.querySelector('#crewStatus')!.textContent = step >= 8 ? '3 RECOVERED' : step >= 6 ? '3 LOCATED' : 'UNKNOWN'
  crashMarker.classList.toggle('hidden', step < 3)
  smoke.classList.toggle('hidden', step < 3 || step >= 8)
  requestAnimationFrame(() => (document.querySelector<HTMLElement>('#alertBar')!.style.width = '100%'))
  next.disabled = step >= steps.length - 1
}

trigger.addEventListener('click', () => { step = 0; trigger.disabled = true; next.disabled = false; render() })
next.addEventListener('click', () => { if (step < steps.length - 1) { step += 1; render() } })
