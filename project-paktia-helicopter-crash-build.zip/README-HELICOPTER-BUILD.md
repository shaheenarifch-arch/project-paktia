# Project Paktia: Falcon-2 Crash Build

Overlay the included `src/` and `ui/` folders onto `/workspaces/project-paktia`.

## Validate

```bash
cd /workspaces/project-paktia
npm install
npm run typecheck
npm test
cd ui
npm run build
```

## Run UI

```bash
cd /workspaces/project-paktia/ui
npm run dev -- --host 0.0.0.0
```

The UI includes a complete clickable crash sequence demo. Select **TRIGGER FALCON EVENT**, then **ADVANCE SEQUENCE**.
