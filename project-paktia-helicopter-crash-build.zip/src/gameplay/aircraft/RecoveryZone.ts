import { distance } from '../../core/types.js'
import type { Vector3 } from '../../core/types.js'

export type RecoveryZoneState = 'INACTIVE' | 'DESIGNATED' | 'ACTIVE' | 'CONTESTED' | 'SECURED' | 'EVACUATION_COMPLETE'

export class RecoveryZone {
  state: RecoveryZoneState = 'INACTIVE'
  center: Vector3 | undefined

  designate(center: Vector3): void { this.center = { ...center }; this.state = 'DESIGNATED' }
  activate(): void { if (this.state === 'DESIGNATED') this.state = 'ACTIVE' }
  contest(): void { if (['ACTIVE', 'SECURED'].includes(this.state)) this.state = 'CONTESTED' }
  secure(): void { if (['ACTIVE', 'CONTESTED'].includes(this.state)) this.state = 'SECURED' }
  completeEvacuation(): void { if (this.state === 'SECURED') this.state = 'EVACUATION_COMPLETE' }
  contains(position: Vector3, radius = 40): boolean { return this.center ? distance(this.center, position) <= radius : false }
}
